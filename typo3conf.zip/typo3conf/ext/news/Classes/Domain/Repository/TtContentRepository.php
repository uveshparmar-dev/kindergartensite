<?php

/*
 * This file is part of the "news" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 */

namespace GeorgRinger\News\Domain\Repository;

use GeorgRinger\News\Domain\Model\TtContent;
use TYPO3\CMS\Extbase\Persistence\Repository;

/**
 * Repository for tt_content objects
 */
class TtContentRepository extends Repository
{
    protected $objectType = TtContent::class;
}
